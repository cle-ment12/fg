<?php
  // Datos de la base de datos
  $servername = "82.197.82.130"; // Cambia si es necesario
  $username = "u289687699_ExpUser1"; // Tu usuario de MySQL
  $password = ":7iLYI7n"; // Tu contraseña de MySQL
  $dbname = "u289687699_ExpUser"; // Nombre de la base de datos
  
  // Conectar a la base de datos
  $conn = new mysqli($servername, $username, $password, $dbname);
  
  if ($conn->connect_error) {
      die("Connection failed: " . $conn->connect_error);
  }

  // Obtener los datos del formulario
  $name = $_POST['name'];
  $email = $_POST['email'];
  $phone = $_POST['phone'];
  $date = $_POST['date'];
  $time = $_POST['time'];
  $people = $_POST['people'];
  $message = $_POST['message'];

  // Insertar los datos en la base de datos
  $sql = "INSERT INTO reservas_mesa (nombre, email, telefono, fecha, hora, personas, mensaje)
          VALUES ('$name', '$email', '$phone', '$date', '$time', '$people', '$message')";

  if ($conn->query($sql) === TRUE) {
      echo "Reserva registrada correctamente.";
  } else {
      echo "Error: " . $sql . "<br>" . $conn->error;
  }

  $conn->close();
?>


