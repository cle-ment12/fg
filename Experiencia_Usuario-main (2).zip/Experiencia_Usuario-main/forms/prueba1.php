<?php
// Datos de conexión a la base de datos
$servername = "82.197.82.130";
$username = "u289687699_ExpUser1";
$password = ":7iLYI7n";
$dbname = "u289687699_ExpUser";

// Crear conexión
$conn = new mysqli($servername, $username, $password, $dbname);

// Verificar conexión
if ($conn->connect_error) {
    die("Conexión fallida: " . $conn->connect_error);
}

// Verificar si el formulario fue enviado
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Recoger datos del formulario
    $name = $conn->real_escape_string($_POST['name']);
    $email = $conn->real_escape_string($_POST['email']);
    $phone = $conn->real_escape_string($_POST['phone']);
    $date = $conn->real_escape_string($_POST['date']);
    $time = $conn->real_escape_string($_POST['time']);
    $people = $conn->real_escape_string($_POST['people']);
    $message = $conn->real_escape_string($_POST['message']);

    // Insertar datos en la base de datos
    $sql = "INSERT INTO reservas (name, email, phone, date, time, people, message) 
            VALUES ('$name', '$email', '$phone', '$date', '$time', '$people', '$message')";

    if ($conn->query($sql) === TRUE) {
        echo "Tu reserva se ha registrado correctamente.";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Cerrar conexión
$conn->close();
?>
